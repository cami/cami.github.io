LSM9DS1 for ESPr Developer by Switch Science
====

[ESPr® Developer用9軸慣性計測ユニットシールド](http://ssci.to/2807)

Sparkfunの[LSM9DS1ライブラリ](https://github.com/sparkfun/SparkFun_LSM9DS1_Arduino_Library)をインストールしておいてください。