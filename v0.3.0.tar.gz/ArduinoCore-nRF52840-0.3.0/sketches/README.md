## Additional libraries

### ArduCAM

| Title | Content |
|:-----:|:------- |
| library name | Arduino-master |
| product page | https://www.arducam.com/ |
| library site | https://github.com/ArduCAM/Arduino |


### Adafruit AMG8833 8x8 Thermal Camera Sensor

| Title | Content |
|:-----:|:------- |
| library name | samplecodes-master/AMG88_breakout |
| product page | https://learn.adafruit.com/adafruit-amg8833-8x8-thermal-camera-sensor |
| library site | https://github.com/SWITCHSCIENCE/samplecodes |


### Wio Extension RTC

| Title | Content |
|:-----:|:------- |
| library name | Wio_Extension_RTC-master |
| product page | http://wiki.seeedstudio.com/Wio-Extension-RTC/ |
| library site | https://github.com/Seeed-Studio/Wio_Extension_RTC |


### Grove - IMU 10DOF v2.0

| Title | Content |
|:-----:|:------- |
| library name | Grove_IMU_10DOF_v2.0-master |
| product page | http://wiki.seeedstudio.com/Grove-IMU_10DOF_v2.0/ |
| library site | https://github.com/Seeed-Studio/Grove_IMU_10DOF_v2.0 |


### Grove - LCD RGB Backlight

| Title | Content |
|:-----:|:------- |
| library name | Grove_LCD_RGB_Backlight-master |
| product page | http://wiki.seeedstudio.com/Grove-LCD_RGB_Backlight/ |
| library site | https://github.com/Seeed-Studio/Grove_LCD_RGB_Backlight |


### Grove - LED Bar

| Title | Content |
|:-----:|:------- |
| library name | Grove_LED_Bar-master |
| product page | http://wiki.seeedstudio.com/Grove-LED_Bar/ |
| library site | https://github.com/Seeed-Studio/Grove_LED_Bar |


### Grove - OLED Display 1.12"

| Title | Content |
|:-----:|:------- |
| library name | OLED_Display_96X96-master |
| product page | http://wiki.seeedstudio.com/Grove-OLED_Display_1.12inch/ |
| library site | https://github.com/Seeed-Studio/OLED_Display_96X96 |


### BASE64

Base64 encoder/decoder for arduino repo

| Title | Content |
|:-----:|:------- |
| library name | base64_arduino-master |
| library page | https://www.arduinolibraries.info/libraries/base64 |
| library site | https://github.com/Densaugeo/base64_arduino |


### MQTT

A client library for MQTT messaging.

| Title | Content |
|:-----:|:------- |
| library name | pubsubclient-master |
| library page | https://www.arduinolibraries.info/libraries/pub-sub-client |
| library site | https://github.com/knolleary/pubsubclient |


### GPS encoder

A new, customizable Arduino NMEA parsing library

| Title | Content |
|:-----:|:------- |
| library name | TinyGPSPlus-feature-grove-gps |
| library page | http://arduiniana.org/2013/09/tinygps-a-new-view-of-global-positioning/ |
| library site | https://github.com/cami/TinyGPSPlus |

