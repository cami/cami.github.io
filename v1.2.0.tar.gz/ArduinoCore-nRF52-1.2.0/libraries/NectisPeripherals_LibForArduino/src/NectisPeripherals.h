#pragma once

namespace peripherals {
  void PutFlashRomIntoDeepSleep(void);
  void WakeUpFlashRomFromDeepSleep(void);
}
