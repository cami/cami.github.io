#pragma once

#include "NectisCellularConfig.h"

#include <map>

class NectisCellularHttpHeader : public std::map<String, String> {
};