日本語フォントROM GT20L16J1Yピッチ変換済みモジュール Arduino用サンプルスケッチ
====
ROMから任意のフォントデータを読みだす

使い方
----

 + [スイッチサイエンスwikiを参照](http://trac.switch-science.com/wiki/KanjiROM)

関連情報
----

1. [日本語フォントROM GT20L16J1Yピッチ変換済みモジュール](https://www.switch-science.com/catalog/2273/)
