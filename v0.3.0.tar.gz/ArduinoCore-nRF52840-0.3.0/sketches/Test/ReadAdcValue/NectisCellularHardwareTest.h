#pragma once

#include <Uart.h>

#include "WioCellLibforArduino.h"
#include "WioCellularHardware.h"


class NectisHardwareTest {
    public:
    NectisHardwareTest();
    void ReadAdcValues();
};