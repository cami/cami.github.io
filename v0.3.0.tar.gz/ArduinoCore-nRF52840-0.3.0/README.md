# BSP, library and sample sketches for Qibanca nectis series

![Arduino](https://img.shields.io/static/v1.svg?label=Arduino&message=1.8.9&color=information)
[![GPL 3.0 License](https://img.shields.io/static/v1.svg?label=license&message=GPL3.0&color=blue)](LICENSE)  

This repository contains the Arduino BSP for nRF52840, Library for BG96 and sample sketches.
    

## Development Environment
- Arduino IDE: 1.8.9  
- Compiler: gcc-arm-none-eabi-5_2-2015q4  

To burn bootloader;  
- JLink Software and Documentation Pack: V6.44a  
- nRF5 Command Line Tools: Win64 9.8.1  


## Installing the Arduino IDE

#### Install Arduino IDE

- macOS

Download the installer from; https://www.arduino.cc/en/main/software

Select `Mac OS X` and the installer will be started soon.

FYI: Default Arduino IDE location; 

```
/Applications/Arduino
```

- Windows

Download the installer from; https://www.arduino.cc/en/main/software

Select `Windows Installer, for Windows XP and up` and the installer will be started soon.

FYI: Default Arduino IDE location; 

```
C:\Program Files(x86)\Arduino
```


## Installing the GNU compiler collection

- [Install the GNU compiler collection](https://github.com/cami/ArduinoCore-nRF52/tree/bb51c11bf4a7ef1155b27ff4ba0b7307c8d0f9c8#optional-core-development-adafruit-nrf52-bsp-via-git)  

1. Start the Arduino IDE

1. Go into Preferences

1. Add https://www.adafruit.com/package_adafruit_index.json as an 'Additional Board Manager URL'

1. Restart the Arduino IDE

1. Open the Boards Manager from the Tools -> Board menu and install 'Adafruit nRF52 by Adafruit'

    Please make sure that you select the version 0.10.1

1. Once the BSP is installed, select 'Adafruit Bluefruit nRF52 Feather' from the Tools -> Board menu, which will update your system config to use the right compiler and settings for the nRF52.

1. Delete the core folder nrf52 installed by Board Manager in Adruino15.

- macOS: ~/Library/Arduino15/packages/adafruit/hardware/nrf52   
- Windows: %APPDATA%/Local/Arduino15/packages/adafruit/hardware/nrf52


## Downloading the source code

1. Clone this repo

Clone this repository to;

- macOS: /Users/<User Name>/Documents/Arduino/libraries
- Windows: /C/Users/<User Name>/Documents/Arduino/libraries

```
$ git clone --recursive git@github.com:cami/BG96_controller_for_nRF52840_LibforArduino.git
```

2. Set Sketchbook location

Set Sketchbook location to the same as where this repo is cloned.

Open `Arduino IDE` and go to `File -> Preferences`.

Set Sketchbook location to;

- macOS: ~/Documents/Arduino/libraries/Arduino-sketches
- Windows: C:\Users\<User Name>\Documents\Arduino-sketches


3. Restart the Arduino IDE


## Setting Execution Envitonment

1. Checkout the branch to `feature/succeed-in-communicating-with-LTE-M` in the following directory: `BG96_controller_for_nRF52840_LibforArduino/hardware/cami/nrf52`

```
$ git checkout feature/succeed-in-communicating-with-LTE-M
```

2. Checkout the branch to `feature/succeed-in-communicating-with-LTE-M` in the following directory: `BG96_controller_for_nRF52840_LibforArduino/libraries/bg96`

```
$ git checkout feature/succeed-in-communicating-with-LTE-M
```

3. Checkout the branch to `feature/grove-gps` in the following directory: `BG96_controller_for_nRF52840_LibforArduino/libraries/TinyGPSPlus`

```
$ git checkout feature/grove-gps
```

4. Add Board: `CAMI qibanca nectis series on nRF52840`

    Go to `Tools -> Board` and select one


5. Select Sketches

    Go to `File -> Sketchbook -> sketches`
    

## Burning new bootloader (IF NEEDED)

To burn the bootloader from within the Arduino IDE, you will need the following tools installed on your system and available in the system path.

- Segger [JLink Software and Documentation Pack](https://www.segger.com/downloads/jlink)
- Nordic [nRF5 Command Line Tools](https://www.nordicsemi.com/?sc_itemid=%7B56868165-9553-444D-AA57-15BDE1BF6B49%7D)

**macOS Note**: You need to create a symlink in `/usr/loacl/bin` to the `nrfjprog`.

You can run the following command to add it, for example;

```
$ ln -s <Download Path>/nRF-Command-Line-Tools_9_8_1_OSX/nrfjprog/nrfjprog /usr/local/bin/nrfjprog
```

Check to make sure you can run `nrfjprog -v` from your terminal/command prompt and you can get the version info.

Once the tools above have been installed and added to your system path, from the Arduino IDE:

- Select `Tools > Board > CAMI qibanca nectis series on nRF52840`
- Select `Tools > Programmer > J-Link for qibanca nectis series on nRF52`
- Select `Tools > Burn Bootloader` with the board and J-Link connected

If you wish to modify bootloader to your own need, check out its repo here [Adafruit_nRF52_Bootloader](https://github.com/adafruit/Adafruit_nRF52_Bootloader)
