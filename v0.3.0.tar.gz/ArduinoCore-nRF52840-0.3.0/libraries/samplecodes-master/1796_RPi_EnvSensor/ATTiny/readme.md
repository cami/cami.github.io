ATtiny85 の Fuses の値は

- EXTENDED ---- 0xFF
- HIGH -------- 0xDF
- LOW --------- 0xE2

です。

ATtiny85 Fuses parameters are as follows:

- EXTENDED ---- 0xFF
- HIGH -------- 0xDF
- LOW --------- 0xE2
