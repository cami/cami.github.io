#pragma once

#include <bluefruit.h>
#include <Bluefruit_FileIO.h>


class NectisCellularExternalFlash {
public:
    NectisCellularExternalFlash();
    virtual ~NectisCellularExternalFlash();
};