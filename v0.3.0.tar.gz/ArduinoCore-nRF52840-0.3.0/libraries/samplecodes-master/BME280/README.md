このリポジトリの内容は https://github.com/SWITCHSCIENCE/samplecodes に移動しました。
これ以降、コードのアップデートがある場合は、移動先でのみ行う予定です。

# BME280

BME280 is environmental sensor that makes Bosch Sensortec. It can sense pressure, humidity and temperature.  
[http://www.bosch-sensortec.com/en/homepage/products_3/environmental_sensors_1/bme280/bme280_1](http://www.bosch-sensortec.com/en/homepage/products_3/environmental_sensors_1/bme280/bme280_1)

## How to use
[BME280搭載　温湿度・気圧センサモジュールの使い方](http://trac.switch-science.com/wiki/BME280) (Japanese)

## Buy
[BME280搭載　温湿度・気圧センサモジュール](https://www.switch-science.com/catalog/2236/) for Japan  
[BME280 Temperature/Humidity/Barometric Pressure Sensor Breakout](https://international.switch-science.com/catalog/2236/) for Worldwide.
