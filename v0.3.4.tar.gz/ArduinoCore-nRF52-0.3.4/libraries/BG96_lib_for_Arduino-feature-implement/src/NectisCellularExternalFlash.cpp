#include "NectisCellularExternalFlash.h"

//#define VOLUME_LABEL        "Nectis"
//const char README_CONTENT[] =
//    "This drive can be used to add or remove files to the on-board \r\n"
//    "SPI flash IC on the Nectis Cellular.\r\n"
//    "\r\n"
//    "For information on how to use Nectis Cellular, see the following links:\r\n"
//    "\r\n"
//    "GitHub repository:\r\n"
//    "https://github.com/cami/BG96_controller_for_nRF52840_LibforArduino\r\n";


NectisCellularExternalFlash::NectisCellularExternalFlash() {
}

NectisCellularExternalFlash::~NectisCellularExternalFlash () {
}
