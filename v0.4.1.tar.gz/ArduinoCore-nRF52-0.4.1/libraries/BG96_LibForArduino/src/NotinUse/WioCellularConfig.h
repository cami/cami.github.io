#pragma once

#include <Arduino.h>

#undef max /* FIXME workaround: https://stackoverflow.com/questions/41093090/esp8266-error-macro-min-passed-3-arguments-but-takes-just-2 */
#undef min /* FIXME workaround: https://stackoverflow.com/questions/41093090/esp8266-error-macro-min-passed-3-arguments-but-takes-just-2 */

#define WIO_DEBUG
