#include "NectisFlags.h"

NectisFlags::NectisFlags() {

}

void NectisFlags::ClearFlags(uint16_t *flags) {
  *flags = 0x0000;
}

