#pragma once

#include "NectisCellularConfig.h"

#include <map>

class WioCellularHttpHeader : public std::map<String, String> {
};
