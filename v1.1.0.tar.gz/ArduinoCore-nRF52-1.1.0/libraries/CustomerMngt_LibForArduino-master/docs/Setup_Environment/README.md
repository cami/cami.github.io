```
————environment————
$ pipenv —python 3.7.3
$ pipenv shell

$ pipenv install hoge
$ pipenv install	# Pipfileからパッケージをインストール
$ pipenv sync		# Pipfile.lockからパッケージをインストール
————environment————
```


